/**
 * @file upper_state_reader.cpp
 * @brief Atom Robot Upper State Reader - 上肢状态读取程序
 * @author Dobot
 * @date 2024
 * 
 * 功能说明：
 * - 订阅上肢状态话题 /upper/state
 * - 实时打印上肢电机状态、BMS状态等信息
 * - 包含机械臂和头部的12个电机状态
 */

#include "rclcpp/rclcpp.hpp"
#include "dobot_atom/msg/upper_state.hpp"

// 信息打印控制开关
const bool INFO_UPPER_STATE = true;

using std::placeholders::_1;

class UpperStateReader : public rclcpp::Node
{
public:
    UpperStateReader() : Node("upper_state_reader")
    {
        // Subscribe to upper state topic
        upper_state_sub_ = this->create_subscription<dobot_atom::msg::UpperState>(
            "/upper/state", 10, std::bind(&UpperStateReader::upper_state_callback, this, _1));
        
        RCLCPP_INFO(this->get_logger(), "Upper State Reader Node Started");
        RCLCPP_INFO(this->get_logger(), "Subscribing to topic: /upper/state");
    }

private:
    void upper_state_callback(const dobot_atom::msg::UpperState::SharedPtr msg)
    {
        if (INFO_UPPER_STATE)
        {
            RCLCPP_INFO(this->get_logger(), "=== Upper State ===");
            RCLCPP_INFO(this->get_logger(), "Upper Control: %s, FSM ID: %d", 
                       msg->is_upper_control ? "Enabled" : "Disabled", msg->fsm_id);
            
            // Motor States (arms and head)
            for (int i = 0; i < 12; i++)
            {
                RCLCPP_INFO(this->get_logger(), "Upper Motor[%d] - Mode: %d, Pos: %.3f, Vel: %.3f, Tau: %.3f, Temp: %d°C",
                           i, msg->motor_state[i].mode, msg->motor_state[i].q, 
                           msg->motor_state[i].dq, msg->motor_state[i].tau_est, msg->motor_state[i].motor_temp);
            }
            
            // BMS State
            RCLCPP_INFO(this->get_logger(), "Upper BMS - SOC: %d%%, Voltage: %dV, Current: %dA",
                       msg->bms_state.battery_level, msg->bms_state.battery_pack_current_voltage, msg->bms_state.battery_now_current);
        }
    }
    
    // Subscriber
    rclcpp::Subscription<dobot_atom::msg::UpperState>::SharedPtr upper_state_sub_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);                                    // Initialize rclcpp
    rclcpp::spin(std::make_shared<UpperStateReader>());          // Run ROS2 node
    rclcpp::shutdown();
    return 0;
}